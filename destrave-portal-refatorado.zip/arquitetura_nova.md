# Nova Arquitetura - Portal Destrave na Hora H

## 🏗️ Estrutura de Pastas Proposta

```
destrave-portal/
├── src/
│   ├── components/           # Componentes reutilizáveis
│   │   ├── ui/              # Componentes base (Button, Card, Modal)
│   │   ├── layout/          # Header, Footer, Navigation
│   │   ├── forms/           # LoginForm, QuizForm
│   │   └── modules/         # ModuleCard, ProgressBar
│   ├── pages/               # Páginas principais
│   │   ├── Login.js
│   │   ├── Dashboard.js
│   │   ├── ModuleContent.js
│   │   └── Certificate.js
│   ├── styles/              # Estilos organizados
│   │   ├── tokens/          # Design tokens
│   │   ├── components/      # Estilos por componente
│   │   ├── utilities/       # Classes utilitárias
│   │   └── globals.css      # Estilos globais
│   ├── data/                # Dados da aplicação
│   │   ├── modules.json     # Conteúdo dos módulos
│   │   ├── quizzes.json     # Perguntas e respostas
│   │   └── user.json        # Dados do usuário
│   ├── utils/               # Funções utilitárias
│   │   ├── storage.js       # LocalStorage helpers
│   │   ├── validation.js    # Validações
│   │   └── animations.js    # Animações
│   └── hooks/               # React hooks customizados
│       ├── useProgress.js
│       ├── useLocalStorage.js
│       └── useAnimation.js
├── public/
│   ├── icons/               # Ícones SVG
│   ├── images/              # Imagens otimizadas
│   └── manifest.json        # PWA manifest
├── docs/                    # Documentação
└── tests/                   # Testes automatizados
```

## 🎨 Sistema de Design Tokens

### **Cores**
```css
:root {
  /* Primary Colors */
  --color-primary-50: #eff6ff;
  --color-primary-100: #dbeafe;
  --color-primary-500: #3b82f6;
  --color-primary-600: #2563eb;
  --color-primary-700: #1d4ed8;
  --color-primary-900: #1e3a8a;

  /* Secondary Colors */
  --color-secondary-50: #f0fdfa;
  --color-secondary-500: #06b6d4;
  --color-secondary-600: #0891b2;

  /* Neutral Colors */
  --color-neutral-50: #f9fafb;
  --color-neutral-100: #f3f4f6;
  --color-neutral-500: #6b7280;
  --color-neutral-700: #374151;
  --color-neutral-900: #111827;

  /* Semantic Colors */
  --color-success: #10b981;
  --color-warning: #f59e0b;
  --color-error: #ef4444;
  --color-info: #3b82f6;
}
```

### **Tipografia**
```css
:root {
  /* Font Families */
  --font-primary: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  --font-heading: 'Poppins', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;

  /* Font Sizes (Fluid Typography) */
  --text-xs: clamp(0.75rem, 0.7rem + 0.25vw, 0.875rem);
  --text-sm: clamp(0.875rem, 0.8rem + 0.375vw, 1rem);
  --text-base: clamp(1rem, 0.9rem + 0.5vw, 1.125rem);
  --text-lg: clamp(1.125rem, 1rem + 0.625vw, 1.25rem);
  --text-xl: clamp(1.25rem, 1.1rem + 0.75vw, 1.5rem);
  --text-2xl: clamp(1.5rem, 1.3rem + 1vw, 2rem);
  --text-3xl: clamp(1.875rem, 1.6rem + 1.375vw, 2.5rem);
  --text-4xl: clamp(2.25rem, 1.9rem + 1.75vw, 3rem);

  /* Line Heights */
  --leading-tight: 1.25;
  --leading-normal: 1.5;
  --leading-relaxed: 1.75;
}
```

### **Espaçamento**
```css
:root {
  /* Spacing Scale (8pt grid) */
  --space-1: 0.25rem;   /* 4px */
  --space-2: 0.5rem;    /* 8px */
  --space-3: 0.75rem;   /* 12px */
  --space-4: 1rem;      /* 16px */
  --space-5: 1.25rem;   /* 20px */
  --space-6: 1.5rem;    /* 24px */
  --space-8: 2rem;      /* 32px */
  --space-10: 2.5rem;   /* 40px */
  --space-12: 3rem;     /* 48px */
  --space-16: 4rem;     /* 64px */
  --space-20: 5rem;     /* 80px */
  --space-24: 6rem;     /* 96px */
}
```

### **Breakpoints Responsivos**
```css
:root {
  --breakpoint-xs: 320px;   /* Mobile pequeno */
  --breakpoint-sm: 480px;   /* Mobile */
  --breakpoint-md: 768px;   /* Tablet */
  --breakpoint-lg: 1024px;  /* Desktop pequeno */
  --breakpoint-xl: 1280px;  /* Desktop */
  --breakpoint-2xl: 1536px; /* Desktop grande */
}
```

## 🧩 Componentes Reutilizáveis

### **Button Component**
```jsx
const Button = ({ 
  variant = 'primary', 
  size = 'md', 
  children, 
  loading = false,
  disabled = false,
  ...props 
}) => {
  const baseClasses = 'btn btn--base';
  const variantClasses = `btn--${variant}`;
  const sizeClasses = `btn--${size}`;
  
  return (
    <button 
      className={`${baseClasses} ${variantClasses} ${sizeClasses}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? <Spinner /> : children}
    </button>
  );
};
```

### **Card Component**
```jsx
const Card = ({ 
  children, 
  variant = 'default',
  padding = 'md',
  shadow = 'md',
  className = '',
  ...props 
}) => {
  return (
    <div 
      className={`card card--${variant} card--padding-${padding} card--shadow-${shadow} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};
```

### **Modal Component**
```jsx
const Modal = ({ 
  isOpen, 
  onClose, 
  title, 
  children,
  size = 'md' 
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div 
        className={`modal modal--${size}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal__header">
          <h3 className="modal__title">{title}</h3>
          <button className="modal__close" onClick={onClose}>×</button>
        </div>
        <div className="modal__content">
          {children}
        </div>
      </div>
    </div>
  );
};
```

## 📱 Estratégia de Responsividade

### **Mobile-First Approach**
```css
/* Base styles (mobile) */
.container {
  padding: var(--space-4);
  max-width: 100%;
}

/* Tablet */
@media (min-width: 768px) {
  .container {
    padding: var(--space-6);
    max-width: 768px;
    margin: 0 auto;
  }
}

/* Desktop */
@media (min-width: 1024px) {
  .container {
    padding: var(--space-8);
    max-width: 1024px;
  }
}

/* Large Desktop */
@media (min-width: 1280px) {
  .container {
    max-width: 1200px;
  }
}
```

### **Grid System Flexível**
```css
.grid {
  display: grid;
  gap: var(--space-4);
  grid-template-columns: 1fr;
}

@media (min-width: 768px) {
  .grid--2-cols { grid-template-columns: repeat(2, 1fr); }
  .grid--3-cols { grid-template-columns: repeat(3, 1fr); }
}

@media (min-width: 1024px) {
  .grid--4-cols { grid-template-columns: repeat(4, 1fr); }
  .grid--auto-fit { 
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
  }
}
```

## ⚡ Estratégia de Performance

### **Critical CSS**
- Extrair CSS crítico para above-the-fold
- Lazy load CSS não crítico
- Usar CSS-in-JS para componentes específicos

### **JavaScript Optimization**
- Code splitting por rota
- Lazy loading de módulos
- Tree shaking para remover código não usado
- Service Worker para cache inteligente

### **Image Optimization**
- Converter para WebP/AVIF
- Responsive images com srcset
- Lazy loading com Intersection Observer
- Placeholder blur effect

## 🎯 Melhorias de Acessibilidade

### **Estrutura Semântica**
```html
<main role="main" aria-label="Conteúdo principal">
  <section aria-labelledby="modules-heading">
    <h2 id="modules-heading">Módulos da Jornada</h2>
    <!-- conteúdo -->
  </section>
</main>
```

### **Navegação por Teclado**
```css
.focus-visible {
  outline: 2px solid var(--color-primary-500);
  outline-offset: 2px;
}

.skip-link {
  position: absolute;
  top: -40px;
  left: 6px;
  background: var(--color-primary-600);
  color: white;
  padding: 8px;
  text-decoration: none;
  transition: top 0.3s;
}

.skip-link:focus {
  top: 6px;
}
```

### **Screen Reader Support**
```jsx
<button 
  aria-label="Iniciar módulo sobre introversão"
  aria-describedby="module-1-description"
>
  Começar Módulo
</button>
<div id="module-1-description" className="sr-only">
  Este módulo ensina sobre os fundamentos da introversão
</div>
```

## 🔄 Sistema de Estado

### **Context API para Estado Global**
```jsx
const AppContext = createContext();

const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [modules, setModules] = useState([]);
  const [progress, setProgress] = useState({});

  return (
    <AppContext.Provider value={{
      user, setUser,
      modules, setModules,
      progress, setProgress
    }}>
      {children}
    </AppContext.Provider>
  );
};
```

### **Custom Hooks para Lógica**
```jsx
const useProgress = () => {
  const { progress, setProgress } = useContext(AppContext);
  
  const updateProgress = (moduleId, pageId) => {
    setProgress(prev => ({
      ...prev,
      [moduleId]: {
        ...prev[moduleId],
        completedPages: [...(prev[moduleId]?.completedPages || []), pageId]
      }
    }));
  };

  return { progress, updateProgress };
};
```

Esta nova arquitetura transformará completamente a aplicação, tornando-a moderna, escalável e mantível.

