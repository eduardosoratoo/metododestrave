# Sistema de Componentes - Portal Destrave na Hora H

## 🎨 Design System Tokens Detalhado

### **Paleta de Cores Expandida**
```css
:root {
  /* Brand Colors */
  --brand-primary: #1e40af;
  --brand-secondary: #06b6d4;
  --brand-accent: #7c3aed;
  
  /* Primary Scale */
  --primary-50: #eff6ff;
  --primary-100: #dbeafe;
  --primary-200: #bfdbfe;
  --primary-300: #93c5fd;
  --primary-400: #60a5fa;
  --primary-500: #3b82f6;
  --primary-600: #2563eb;
  --primary-700: #1d4ed8;
  --primary-800: #1e40af;
  --primary-900: #1e3a8a;
  
  /* Success Scale */
  --success-50: #f0fdf4;
  --success-100: #dcfce7;
  --success-500: #10b981;
  --success-600: #059669;
  --success-700: #047857;
  
  /* Warning Scale */
  --warning-50: #fffbeb;
  --warning-100: #fef3c7;
  --warning-500: #f59e0b;
  --warning-600: #d97706;
  
  /* Error Scale */
  --error-50: #fef2f2;
  --error-100: #fee2e2;
  --error-500: #ef4444;
  --error-600: #dc2626;
  
  /* Neutral Scale */
  --neutral-0: #ffffff;
  --neutral-50: #f9fafb;
  --neutral-100: #f3f4f6;
  --neutral-200: #e5e7eb;
  --neutral-300: #d1d5db;
  --neutral-400: #9ca3af;
  --neutral-500: #6b7280;
  --neutral-600: #4b5563;
  --neutral-700: #374151;
  --neutral-800: #1f2937;
  --neutral-900: #111827;
}
```

### **Shadows & Effects**
```css
:root {
  /* Shadows */
  --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-sm: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  --shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
  
  /* Glows */
  --glow-primary: 0 0 20px rgba(59, 130, 246, 0.3);
  --glow-success: 0 0 20px rgba(16, 185, 129, 0.3);
  --glow-warning: 0 0 20px rgba(245, 158, 11, 0.3);
  
  /* Blur */
  --blur-sm: blur(4px);
  --blur-md: blur(8px);
  --blur-lg: blur(16px);
}
```

### **Border Radius**
```css
:root {
  --radius-none: 0;
  --radius-sm: 0.125rem;
  --radius-md: 0.375rem;
  --radius-lg: 0.5rem;
  --radius-xl: 0.75rem;
  --radius-2xl: 1rem;
  --radius-3xl: 1.5rem;
  --radius-full: 9999px;
}
```

### **Transitions & Animations**
```css
:root {
  /* Durations */
  --duration-75: 75ms;
  --duration-100: 100ms;
  --duration-150: 150ms;
  --duration-200: 200ms;
  --duration-300: 300ms;
  --duration-500: 500ms;
  --duration-700: 700ms;
  --duration-1000: 1000ms;
  
  /* Easings */
  --ease-linear: linear;
  --ease-in: cubic-bezier(0.4, 0, 1, 1);
  --ease-out: cubic-bezier(0, 0, 0.2, 1);
  --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
  --ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
}
```

## 🧩 Componentes Base

### **Button System**
```css
/* Base Button */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  font-weight: 600;
  text-decoration: none;
  border: none;
  cursor: pointer;
  transition: all var(--duration-200) var(--ease-out);
  position: relative;
  overflow: hidden;
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none !important;
}

/* Button Sizes */
.btn--xs {
  padding: var(--space-1) var(--space-2);
  font-size: var(--text-xs);
  border-radius: var(--radius-md);
}

.btn--sm {
  padding: var(--space-2) var(--space-3);
  font-size: var(--text-sm);
  border-radius: var(--radius-lg);
}

.btn--md {
  padding: var(--space-3) var(--space-4);
  font-size: var(--text-base);
  border-radius: var(--radius-xl);
}

.btn--lg {
  padding: var(--space-4) var(--space-6);
  font-size: var(--text-lg);
  border-radius: var(--radius-2xl);
}

/* Button Variants */
.btn--primary {
  background: linear-gradient(135deg, var(--primary-600), var(--primary-500));
  color: var(--neutral-0);
  box-shadow: var(--shadow-md);
}

.btn--primary:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg), var(--glow-primary);
}

.btn--secondary {
  background: var(--neutral-0);
  color: var(--primary-600);
  border: 2px solid var(--primary-200);
}

.btn--secondary:hover {
  background: var(--primary-50);
  border-color: var(--primary-300);
}

.btn--success {
  background: linear-gradient(135deg, var(--success-600), var(--success-500));
  color: var(--neutral-0);
}

.btn--success:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg), var(--glow-success);
}

.btn--warning {
  background: linear-gradient(135deg, var(--warning-600), var(--warning-500));
  color: var(--neutral-0);
}

.btn--warning:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-lg), var(--glow-warning);
}
```

### **Card System**
```css
.card {
  background: var(--neutral-0);
  border-radius: var(--radius-2xl);
  transition: all var(--duration-300) var(--ease-out);
  position: relative;
  overflow: hidden;
}

.card--shadow-sm { box-shadow: var(--shadow-sm); }
.card--shadow-md { box-shadow: var(--shadow-md); }
.card--shadow-lg { box-shadow: var(--shadow-lg); }
.card--shadow-xl { box-shadow: var(--shadow-xl); }

.card--padding-sm { padding: var(--space-4); }
.card--padding-md { padding: var(--space-6); }
.card--padding-lg { padding: var(--space-8); }

.card--interactive {
  cursor: pointer;
}

.card--interactive:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-xl);
}

.card--success {
  background: linear-gradient(135deg, var(--success-50), var(--success-100));
  border: 2px solid var(--success-200);
}

.card--warning {
  background: linear-gradient(135deg, var(--warning-50), var(--warning-100));
  border: 2px solid var(--warning-200);
}

.card--locked {
  background: linear-gradient(135deg, var(--warning-50), var(--warning-100));
  border: 2px solid var(--warning-300);
}
```

### **Form Components**
```css
.form-group {
  margin-bottom: var(--space-4);
}

.form-label {
  display: block;
  font-weight: 600;
  color: var(--neutral-700);
  margin-bottom: var(--space-2);
  font-size: var(--text-sm);
}

.form-input {
  width: 100%;
  padding: var(--space-3) var(--space-4);
  border: 2px solid var(--neutral-200);
  border-radius: var(--radius-xl);
  font-size: var(--text-base);
  transition: all var(--duration-200) var(--ease-out);
  background: var(--neutral-0);
}

.form-input:focus {
  outline: none;
  border-color: var(--primary-500);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.form-input--error {
  border-color: var(--error-500);
}

.form-input--error:focus {
  box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
}

.form-input--success {
  border-color: var(--success-500);
}

.form-error {
  color: var(--error-600);
  font-size: var(--text-sm);
  margin-top: var(--space-1);
}
```

### **Progress Components**
```css
.progress-container {
  background: var(--neutral-100);
  border-radius: var(--radius-full);
  overflow: hidden;
  position: relative;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, var(--success-600), var(--success-500));
  border-radius: var(--radius-full);
  transition: width var(--duration-700) var(--ease-out);
  position: relative;
}

.progress-bar::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
  animation: shimmer 2s infinite;
}

@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

.progress--sm { height: 6px; }
.progress--md { height: 8px; }
.progress--lg { height: 12px; }
.progress--xl { height: 16px; }
```

## 📱 Breakpoints Específicos

### **Breakpoints Customizados**
```css
:root {
  /* Mobile First Breakpoints */
  --bp-xs: 320px;    /* iPhone SE */
  --bp-sm: 375px;    /* iPhone 12 */
  --bp-md: 768px;    /* iPad Portrait */
  --bp-lg: 1024px;   /* iPad Landscape / Small Desktop */
  --bp-xl: 1280px;   /* Desktop */
  --bp-2xl: 1536px;  /* Large Desktop */
  
  /* Container Max Widths */
  --container-sm: 640px;
  --container-md: 768px;
  --container-lg: 1024px;
  --container-xl: 1280px;
  --container-2xl: 1536px;
}
```

### **Responsive Grid System**
```css
.container {
  width: 100%;
  margin: 0 auto;
  padding: 0 var(--space-4);
}

@media (min-width: 640px) {
  .container {
    max-width: var(--container-sm);
    padding: 0 var(--space-6);
  }
}

@media (min-width: 768px) {
  .container {
    max-width: var(--container-md);
  }
}

@media (min-width: 1024px) {
  .container {
    max-width: var(--container-lg);
    padding: 0 var(--space-8);
  }
}

@media (min-width: 1280px) {
  .container {
    max-width: var(--container-xl);
  }
}

/* Grid System */
.grid {
  display: grid;
  gap: var(--space-4);
}

.grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }

@media (min-width: 768px) {
  .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
}

@media (min-width: 1024px) {
  .grid-cols-4 { grid-template-columns: repeat(4, minmax(0, 1fr)); }
  .grid-auto-fit { 
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); 
  }
}
```

## 🎭 Microinterações e Animações

### **Hover Effects**
```css
.hover-lift {
  transition: transform var(--duration-200) var(--ease-out);
}

.hover-lift:hover {
  transform: translateY(-2px);
}

.hover-scale {
  transition: transform var(--duration-200) var(--ease-out);
}

.hover-scale:hover {
  transform: scale(1.05);
}

.hover-glow {
  transition: box-shadow var(--duration-300) var(--ease-out);
}

.hover-glow:hover {
  box-shadow: var(--shadow-lg), var(--glow-primary);
}
```

### **Loading States**
```css
.loading-skeleton {
  background: linear-gradient(90deg, var(--neutral-200), var(--neutral-100), var(--neutral-200));
  background-size: 200% 100%;
  animation: skeleton-loading 1.5s infinite;
}

@keyframes skeleton-loading {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

.loading-spinner {
  width: 20px;
  height: 20px;
  border: 2px solid var(--neutral-200);
  border-top: 2px solid var(--primary-500);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
```

### **Page Transitions**
```css
.page-enter {
  opacity: 0;
  transform: translateY(20px);
}

.page-enter-active {
  opacity: 1;
  transform: translateY(0);
  transition: all var(--duration-300) var(--ease-out);
}

.page-exit {
  opacity: 1;
  transform: translateY(0);
}

.page-exit-active {
  opacity: 0;
  transform: translateY(-20px);
  transition: all var(--duration-200) var(--ease-in);
}
```

## 🎯 Componentes Específicos da Aplicação

### **Module Card**
```css
.module-card {
  position: relative;
  overflow: hidden;
}

.module-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, var(--primary-500), var(--secondary-500));
}

.module-card--locked::before {
  background: linear-gradient(90deg, var(--warning-500), var(--warning-400));
}

.module-card--completed::before {
  background: linear-gradient(90deg, var(--success-500), var(--success-400));
}

.module-icon {
  width: 60px;
  height: 60px;
  border-radius: var(--radius-xl);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: var(--text-2xl);
  color: var(--neutral-0);
  margin-bottom: var(--space-4);
}

.module-icon--blue {
  background: linear-gradient(135deg, var(--primary-600), var(--primary-500));
}

.module-icon--teal {
  background: linear-gradient(135deg, var(--secondary-600), var(--secondary-500));
}

.module-icon--purple {
  background: linear-gradient(135deg, var(--brand-accent), #a855f7);
}
```

### **Quiz Component**
```css
.quiz-option {
  background: var(--neutral-0);
  border: 2px solid var(--neutral-200);
  border-radius: var(--radius-xl);
  padding: var(--space-4);
  cursor: pointer;
  transition: all var(--duration-200) var(--ease-out);
  position: relative;
}

.quiz-option:hover {
  border-color: var(--primary-300);
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
}

.quiz-option--selected {
  border-color: var(--primary-500);
  background: var(--primary-50);
}

.quiz-option--correct {
  border-color: var(--success-500);
  background: var(--success-50);
}

.quiz-option--incorrect {
  border-color: var(--error-500);
  background: var(--error-50);
}

.quiz-feedback {
  border-radius: var(--radius-xl);
  padding: var(--space-6);
  margin-top: var(--space-4);
}

.quiz-feedback--correct {
  background: linear-gradient(135deg, var(--success-50), var(--success-100));
  border: 2px solid var(--success-200);
}

.quiz-feedback--incorrect {
  background: linear-gradient(135deg, var(--error-50), var(--error-100));
  border: 2px solid var(--error-200);
}
```

Este sistema de componentes garante consistência visual, acessibilidade e uma experiência de usuário excepcional em todos os dispositivos.

